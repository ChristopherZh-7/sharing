from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Visitor


def get_client_ip(request):
    """获取客户端真实IP地址"""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip


def phishing_page(request):
    """钓鱼演练页面 - 福利申领表单"""
    # 获取访问者IP地址
    ip_address = get_client_ip(request)
    
    # 获取User Agent
    user_agent = request.META.get('HTTP_USER_AGENT', '')
    
    if request.method == 'POST':
        # 处理表单提交
        name = request.POST.get('name', '')
        phone = request.POST.get('phone', '')
        department = request.POST.get('department', '')
        
        # 记录访问和表单信息
        Visitor.objects.create(
            ip_address=ip_address,
            user_agent=user_agent,
            name=name,
            phone=phone,
            department=department,
            submitted=True
        )
        
        # 重定向到感谢页面
        return redirect('phishing:thank_you')
    
    else:
        # GET请求 - 只记录访问
        Visitor.objects.create(
            ip_address=ip_address,
            user_agent=user_agent,
            submitted=False
        )
    
    context = {}
    return render(request, 'phishing/phishing_page.html', context)


def thank_you_page(request):
    """提交成功后的感谢页面"""
    return render(request, 'phishing/thank_you.html')
