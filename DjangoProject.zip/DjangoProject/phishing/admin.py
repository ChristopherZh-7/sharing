from django.contrib import admin
from .models import Visitor


@admin.register(Visitor)
class VisitorAdmin(admin.ModelAdmin):
    list_display = ('name', 'phone', 'department', 'ip_address', 'visit_time', 'submitted')
    list_filter = ('visit_time', 'submitted')
    search_fields = ('ip_address', 'name', 'phone', 'department')
    readonly_fields = ('ip_address', 'visit_time', 'user_agent', 'name', 'phone', 'department', 'submitted')
    
    fieldsets = (
        ('访问信息', {
            'fields': ('ip_address', 'visit_time', 'user_agent')
        }),
        ('提交信息', {
            'fields': ('submitted', 'name', 'phone', 'department')
        }),
    )
    
    def has_add_permission(self, request):
        return False
    
    def has_delete_permission(self, request, obj=None):
        return True
