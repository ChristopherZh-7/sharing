from django.db import models


class Visitor(models.Model):
    # 基本访问信息
    ip_address = models.GenericIPAddressField(verbose_name='IP地址')
    visit_time = models.DateTimeField(auto_now_add=True, verbose_name='访问时间')
    user_agent = models.TextField(blank=True, null=True, verbose_name='User Agent')
    
    # 用户提交的信息
    name = models.CharField(max_length=50, blank=True, null=True, verbose_name='姓名')
    phone = models.CharField(max_length=20, blank=True, null=True, verbose_name='手机号')
    department = models.CharField(max_length=100, blank=True, null=True, verbose_name='部门')
    submitted = models.BooleanField(default=False, verbose_name='是否提交表单')
    
    class Meta:
        verbose_name = '访问记录'
        verbose_name_plural = '访问记录'
        ordering = ['-visit_time']
    
    def __str__(self):
        if self.name:
            return f"{self.name} ({self.ip_address}) - {self.visit_time}"
        return f"{self.ip_address} - {self.visit_time}"
