from django.urls import path
from . import views

app_name = 'phishing'

urlpatterns = [
    path('', views.phishing_page, name='phishing_page'),
    path('thank-you/', views.thank_you_page, name='thank_you'),
]

