from django.db import models


class Visitor(models.Model):
    # param参数 - 对应每个人
    param = models.CharField(max_length=200, default='unknown', verbose_name='参数标识')
    # 访问时间
    visit_time = models.DateTimeField(auto_now_add=True, verbose_name='访问时间')
    # 是否提交了内容（不记录提交的具体内容）
    submitted = models.BooleanField(default=False, verbose_name='是否提交表单')
    
    class Meta:
        verbose_name = '访问记录'
        verbose_name_plural = '访问记录'
        ordering = ['-visit_time']
    
    def __str__(self):
        return f"{self.param} - {self.visit_time} - {'已提交' if self.submitted else '仅访问'}"
