from django.contrib import admin
from .models import Visitor


@admin.register(Visitor)
class VisitorAdmin(admin.ModelAdmin):
    list_display = ('param', 'visit_time', 'submitted')
    list_filter = ('visit_time', 'submitted')
    search_fields = ('param',)
    readonly_fields = ('param', 'visit_time', 'submitted')
    
    fieldsets = (
        ('访问记录', {
            'fields': ('param', 'visit_time', 'submitted')
        }),
    )
    
    def has_add_permission(self, request):
        return False
    
    def has_delete_permission(self, request, obj=None):
        return True
