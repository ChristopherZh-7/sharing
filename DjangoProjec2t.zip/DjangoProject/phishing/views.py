from django.shortcuts import render, redirect
from django.urls import reverse
from .models import Visitor


def phishing_page(request):
    """钓鱼演练页面 - 福利申领表单"""
    # 从GET或POST参数中获取param
    param = request.GET.get('param') or request.POST.get('param', '')
    
    if not param:
        # 如果没有param参数，使用默认值
        param = 'unknown'
    
    if request.method == 'POST':
        # 处理表单提交
        # 注意：不保存提交的具体内容（姓名、电话、部门），只记录param是否提交了
        
        # 获取该param的第一条记录（如果有多条，取最早的一条）
        visitor = Visitor.objects.filter(param=param).order_by('visit_time').first()
        
        if visitor:
            # 如果记录已存在，更新提交状态为True
            visitor.submitted = True
            visitor.save()
        else:
            # 如果记录不存在，创建新记录
            Visitor.objects.create(
                param=param,
                submitted=True
            )
        
        # 重定向到感谢页面，传递param参数
        return redirect(f'{reverse("phishing:thank_you")}?param={param}')
    
    else:
        # GET请求 - 记录访问（如果还没有记录）
        # 检查是否已有记录，如果没有则创建
        visitor = Visitor.objects.filter(param=param).first()
        if not visitor:
            Visitor.objects.create(
                param=param,
                submitted=False
            )
    
    context = {'param': param}
    return render(request, 'phishing/phishing_page.html', context)


def thank_you_page(request):
    """提交成功后的感谢页面"""
    param = request.GET.get('param', '')
    context = {'param': param}
    return render(request, 'phishing/thank_you.html', context)
