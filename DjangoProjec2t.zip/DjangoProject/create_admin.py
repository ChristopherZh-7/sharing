import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'DjangoProject.settings')
django.setup()

from django.contrib.auth import get_user_model
from phishing.models import Visitor

User = get_user_model()

# 创建管理员账号
username = 'admin'
password = 'admin123'
email = 'admin@example.com'

if User.objects.filter(username=username).exists():
    print(f"管理员账号 '{username}' 已存在")
else:
    User.objects.create_superuser(username=username, email=email, password=password)
    print(f"[OK] 管理员账号创建成功！")
    print(f"   用户名: {username}")
    print(f"   密码: {password}")

print("\n" + "="*60)
print("当前访问记录统计")
print("="*60)

# 查看所有访问记录
visitors = Visitor.objects.all()
total = visitors.count()
submitted = visitors.filter(submitted=True).count()

print(f"\n总访问次数: {total}")
print(f"提交表单人数: {submitted}")
print(f"只浏览未提交: {total - submitted}")

if total > 0:
    print("\n" + "-"*60)
    print("最近的访问记录：")
    print("-"*60)
    for v in visitors[:10]:
        if v.submitted:
            print(f"[已提交] [{v.visit_time.strftime('%Y-%m-%d %H:%M:%S')}] {v.name or '未知'} | {v.department or '未知'} | {v.phone or '未知'} | IP: {v.ip_address}")
        else:
            print(f"[仅访问] [{v.visit_time.strftime('%Y-%m-%d %H:%M:%S')}] 未提交表单 | IP: {v.ip_address}")

print("\n" + "="*60)
print("访问管理后台查看完整数据:")
print("   http://127.0.0.1:8000/admin/")
print(f"   用户名: {username}")
print(f"   密码: {password}")
print("="*60)

